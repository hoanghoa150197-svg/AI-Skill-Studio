# Test case
ID:
Đầu vào:
Kết quả mong đợi:
Tiêu chí đạt:
Kết quả thực tế: Chưa chạy
