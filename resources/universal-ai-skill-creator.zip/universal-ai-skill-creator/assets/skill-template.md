---
name: example-skill
description: "Mục đích và điều kiện dùng"
---
# Vai trò
## Đầu vào
## Quy trình
## Quy tắc và giới hạn
## Tài liệu tham chiếu
## Đầu ra
## Kiểm tra
