import pathlib,sys,zipfile,subprocess
p=pathlib.Path(sys.argv[1]).resolve()
subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name("validate-skill.py")),str(p)],check=True)
out=p.parent/(p.name+".zip")
with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
 for x in sorted(p.rglob("*")):
  z.write(x,x.relative_to(p.parent).as_posix())
print(out)
