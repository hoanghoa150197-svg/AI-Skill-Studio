import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); errors=[]
if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*",p.name) or len(p.name)>64: errors.append("Invalid name")
f=p/"SKILL.md"
if not f.is_file(): errors.append("Missing SKILL.md")
else:
 t=f.read_text(encoding="utf-8"); parts=t.split("---",2)
 if not t.startswith("---\n") or len(parts)!=3: errors.append("Missing frontmatter")
 else:
  if not re.search(r"(?m)^name: *"+re.escape(p.name)+r" *$",parts[1]): errors.append("Name mismatch")
  if not re.search(r"(?m)^description: *\S",parts[1]): errors.append("Missing description")
if any(x.is_symlink() for x in p.rglob("*")): errors.append("Symlinks not allowed")
print("\n".join(errors) if errors else "Basic structure OK; content not validated")
sys.exit(bool(errors))
