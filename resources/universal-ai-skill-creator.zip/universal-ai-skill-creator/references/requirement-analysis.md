# Phân tích yêu cầu
Xác định người dùng, nhiệm vụ lặp lại, dữ liệu vào, đầu ra, công cụ khả dụng, tiêu chí đạt, rủi ro. Phân biệt yêu cầu bắt buộc và tùy chọn. Ví dụ kỹ sư cần tải trọng và điều kiện vận hành; không tự suy diễn số liệu.
