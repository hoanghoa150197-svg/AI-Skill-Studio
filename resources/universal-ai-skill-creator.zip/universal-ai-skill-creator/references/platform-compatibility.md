# Tương thích
Native Skill nếu nền tảng hỗ trợ; ZIP attachment nếu có công cụ đọc; Markdown độc lập nếu chỉ hỗ trợ văn bản. Không hứa chạy script hoặc tạo tệp khi không có công cụ.
