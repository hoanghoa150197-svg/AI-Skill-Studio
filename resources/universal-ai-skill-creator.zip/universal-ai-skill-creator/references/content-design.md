# Thiết kế nội dung
Mỗi file phải có mục đích. References ghi nguồn, phiên bản, phạm vi; scripts có đầu vào, đầu ra, phụ thuộc và hướng dẫn chạy; assets là mẫu thực tế; examples mô tả yêu cầu và kết quả; tests có tiêu chí đo được. Không sao chép tài liệu không có quyền. Không bịa kiến thức chuyên ngành.
