# Kiến trúc
SKILL.md bắt buộc; references, scripts, assets tùy chọn theo Agent Skills. Studio bổ sung README, examples, tests. Dùng đường dẫn tương đối; chỉ đọc tài liệu cần thiết. Tên gốc, name YAML và ZIP thống nhất. Tham khảo https://agentskills.io/specification.
