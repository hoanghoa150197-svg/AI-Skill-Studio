# Universal AI Skill Creator
Tải ZIP vào AI có khả năng đọc file hoặc cài theo cơ chế Agent Skills. Yêu cầu: “Hãy tạo Skill hỗ trợ [công việc]”. Mặc định Professional. Nhập ZIP kết quả vào Studio. Nếu AI không đọc ZIP, dùng bản portable Markdown đi kèm website.
