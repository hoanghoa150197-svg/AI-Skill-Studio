# Nghiệm thu
- [ ] Tên gốc, metadata, ZIP khớp
- [ ] SKILL.md có name, description
- [ ] Các tham chiếu tồn tại
- [ ] Ví dụ đúng lĩnh vực
- [ ] Có tình huống thiếu dữ liệu và ngoại lệ
- [ ] Không chứa bí mật hoặc nguồn bịa
- [ ] ZIP giải nén được, đúng một SKILL.md
- [ ] Báo cáo đúng những gì đã kiểm tra
