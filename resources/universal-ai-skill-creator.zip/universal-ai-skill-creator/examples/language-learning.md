# Ví dụ
Yêu cầu: phân tích câu tiếng Anh. Skill trả nghĩa, cấu trúc, từ vựng, collocation, lỗi và ví dụ; không ép một cách phân tích khi câu mơ hồ.
