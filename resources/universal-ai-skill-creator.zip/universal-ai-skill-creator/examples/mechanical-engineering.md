# Ví dụ
Yêu cầu: phân tích phương án băng tải. Skill cần thu thập tải trọng, tốc độ, kích thước, môi trường; đề xuất phương án và kiểm tra giả định. Không tự xác nhận an toàn. Đầu ra: bảng phương án, rủi ro, dữ liệu thiếu.
