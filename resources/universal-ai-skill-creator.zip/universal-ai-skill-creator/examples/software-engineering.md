# Ví dụ
Yêu cầu: sửa lỗi web tĩnh. Skill phân tích mã, tái hiện lỗi, xác định phạm vi, sửa tối thiểu, kiểm thử hồi quy, đóng gói. Nếu không chạy trình duyệt được phải ghi rõ.
